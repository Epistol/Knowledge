<map version="0.9.0">
<!--To view this file, download free mind mapping software Freeplane from http://freeplane.sourceforge.net -->
<node TEXT="Pb : le porte carte pas adapt&#xe9; sur tout les vtt" ID="ID_357632165" CREATED="1361202427299" MODIFIED="1361203098347">
<hook NAME="MapStyle" max_node_width="600"/>
<node TEXT="monde du pb" POSITION="right" ID="ID_482592581" CREATED="1361203153785" MODIFIED="1361205644178" HGAP="10" VSHIFT="-42">
<node TEXT="objet du pb" ID="ID_1395180901" CREATED="1361204432958" MODIFIED="1361204865154" HGAP="26" VSHIFT="-31">
<node TEXT="cintre du vtt" ID="ID_434604295" CREATED="1361204438858" MODIFIED="1361204459994"/>
<node TEXT="porte carte" ID="ID_1535989320" CREATED="1361204462614" MODIFIED="1361204483875"/>
</node>
<node TEXT="objet de l&apos;environnement" ID="ID_1907344471" CREATED="1361204516546" MODIFIED="1361204540502" HGAP="19" VSHIFT="12">
<node TEXT="cycliste" ID="ID_1097415485" CREATED="1361204522499" MODIFIED="1361204530328"/>
<node TEXT="carte" ID="ID_1248170495" CREATED="1361204531313" MODIFIED="1361204535111"/>
</node>
</node>
<node TEXT="premier postulat" POSITION="right" ID="ID_123313379" CREATED="1361204672688" MODIFIED="1361205640260" HGAP="11" VSHIFT="8">
<node TEXT="r&#xe8;gle du monde clos" ID="ID_1538250368" CREATED="1361204705832" MODIFIED="1361204878984" HGAP="14" VSHIFT="-22">
<node TEXT="monde d&apos;1 solution inventive ne comporte pas d&apos;objets qui ne sois pas pr&#xe9;sent ds le mnde du pb" ID="ID_1286356943" CREATED="1361204726343" MODIFIED="1361204927564" HGAP="17" VSHIFT="-30"/>
</node>
</node>
<node TEXT="deuxi&#xe8;me postulat" POSITION="right" ID="ID_1424990606" CREATED="1361204841307" MODIFIED="1361205659663" HGAP="31" VSHIFT="-142">
<node TEXT="la condition de changement qualitatif" ID="ID_547422648" CREATED="1361204974842" MODIFIED="1361205040338" HGAP="17" VSHIFT="-29">
<node TEXT="au - 1 facteur aggravant du monde du pb est chang&#xe9; en facteur neutre ou +" ID="ID_841836667" CREATED="1361205042684" MODIFIED="1361205646972" HGAP="21" VSHIFT="-33">
<node TEXT="Identification ph&#xe9;nom&#xe8;ne ind&#xe9;sirable" ID="ID_289832696" CREATED="1361205186343" MODIFIED="1361205649009" HGAP="30" VSHIFT="-15">
<node TEXT="porte carte non adapt&#xe9; au cintre" ID="ID_1088294419" CREATED="1361205244873" MODIFIED="1361205482610" HGAP="26" VSHIFT="-24"/>
</node>
<node TEXT="Identification du facteur aggravant" ID="ID_1945383733" CREATED="1361205281491" MODIFIED="1361205476238" HGAP="36" VSHIFT="-29">
<node TEXT="+ de diam&#xe8;tre diff&#xe9;rent sur les cintres" ID="ID_370974398" CREATED="1361205325168" MODIFIED="1361205484897" HGAP="27" VSHIFT="-31"/>
</node>
<node TEXT="changement qualitatif" ID="ID_81791605" CREATED="1361205469891" MODIFIED="1361205522035">
<node TEXT="+ il y&apos;a de diam&#xe8;tre diff&#xe9;rent, plus le porte carte s&apos;adapte" ID="ID_36946082" CREATED="1361205524193" MODIFIED="1361205623467" HGAP="22" VSHIFT="-34"/>
</node>
</node>
</node>
</node>
<node TEXT="outil d&apos;aide au changement" POSITION="right" ID="ID_972835546" CREATED="1361205655836" MODIFIED="1361205682285">
<node TEXT="Unification" ID="ID_1991581121" CREATED="1361205688010" MODIFIED="1361205866252" HGAP="51" VSHIFT="-36">
<node TEXT="le porte carte s&apos;adapte au cintre" ID="ID_1002078457" CREATED="1361205918456" MODIFIED="1361205953065" HGAP="25" VSHIFT="-30">
<node TEXT="menottes &#xe0; cran" ID="ID_245322975" CREATED="1361206494993" MODIFIED="1361206509666" VSHIFT="-23"/>
</node>
<node TEXT="le cintre s&apos;adapte au porte carte" ID="ID_884027304" CREATED="1361205967220" MODIFIED="1361205991931">
<node TEXT="changer le diam&#xe8;tre du cintre" ID="ID_1955080525" CREATED="1361206520896" MODIFIED="1361206576748" VSHIFT="-28"/>
</node>
</node>
<node TEXT="Multiplication" ID="ID_550357378" CREATED="1361205782634" MODIFIED="1361205851871" HGAP="38" VSHIFT="-33">
<node TEXT="un objet va permettre au porte carte de d&apos;adapter au cintre du VTT" ID="ID_66656083" CREATED="1361205995516" MODIFIED="1361206036919" HGAP="23" VSHIFT="-16"/>
</node>
<node TEXT="Division" ID="ID_417984110" CREATED="1361205836792" MODIFIED="1361205887660" HGAP="46" VSHIFT="-47">
<node TEXT="un objet sera divis&#xe9; puis r&#xe9;organiser spatio-temporellement" ID="ID_1110964137" CREATED="1361206041426" MODIFIED="1361206085090" HGAP="29" VSHIFT="-25"/>
</node>
<node TEXT="Suppression" ID="ID_1564908274" CREATED="1361205871384" MODIFIED="1361205882121">
<node TEXT="supprimer un objet va permettre au porte carte de s&apos;adapter au cintre" ID="ID_1812350283" CREATED="1361206087366" MODIFIED="1361206292210" HGAP="22" VSHIFT="-21"/>
</node>
<node TEXT="Casser la sym&#xe9;trie" ID="ID_1693945233" CREATED="1361205890885" MODIFIED="1361205904257" HGAP="23" VSHIFT="44">
<node TEXT="enlever la partie sup&#xe9;rieur de la patte et la remplacer par une autre patte de diam&#xe8;tre diff&#xe9;rent" ID="ID_1440355186" CREATED="1361206303658" MODIFIED="1361206416181" HGAP="21" VSHIFT="-27"/>
</node>
</node>
</node>
</map>
